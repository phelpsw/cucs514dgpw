Title: C# Webcam Capture
Description: This is a control I ported from a Visual Basic 6 project which will connect to a webcam and return System.Drawing.Image every x milliseconds. The control returns the image in the ImageCaptured Event. In the example, I show how to configure everything and how to display the image on the screen. It seems to run about 15 frames per second at the fastest, I think because of the overhead of converting to System.Drawing.Image
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=1339&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
